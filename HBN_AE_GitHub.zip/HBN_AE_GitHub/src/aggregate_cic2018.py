import json, glob, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.environ.get("OUT_DIR", os.path.join(ROOT, "results", "cic2018"))
FIG = os.environ.get("FIG_DIR", os.path.join(ROOT, "figures", "cic2018")); os.makedirs(FIG, exist_ok=True)
CLASSES = ["Benign","SSH-BruteForce","DoS-GoldenEye","DoS-Slowloris","DoS-Hulk","DDoS-HOIC"]
seeds = {}
info = None
for f in sorted(glob.glob(f"{OUT}/results_*.json")):
    d = json.load(open(f)); info = d["info"]; seeds.update(d["seeds"])
S = sorted(seeds, key=int)
MODELS = ["HBN+AE", "SAE+SMR", "AE+SVM", "AE+Gaussian+NB", "MLP", "RNN", "RF", "KDB-BN only"]
def ms(model, key):
    v = np.array([seeds[s][model][key] for s in S], float); return v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0
L = []
L.append(f"# HBN-AE on CIC-IDS2018 subset (Python), seeds = {', '.join(S)}\n")
L.append(f"Rows: {info['n_rows']}; raw columns: {info['n_raw_cols']} (incl. label); "
         f"constant (removed): {len(info['constant_cols'])} -> {info['constant_cols']}; "
         f"model inputs after one-hot: {info['n_model_inputs']}; BN nodes: {info['n_bn_nodes']}\n")
sp = seeds[S[0]]["split"]; L.append(f"Split: train {sp['train']} + val {sp['val']} (= {sp['train']+sp['val']}), test {sp['test']}; "
                                    f"train per class {sp['train_per_class']}; test per class {sp['test_per_class']}\n")
L.append("\n## Table 4 (mean ± std over seeds, %, test set)\n")
L.append("| Method | Accuracy | Precision (w) | Recall (w) | F1 (w) | Macro-F1 | Macro AUC | Train (s) | Inference total (s) | Latency (ms/sample) |")
L.append("|---|---|---|---|---|---|---|---|---|---|")
agg = {}
for m in MODELS:
    row = {k: ms(m, k) for k in ["acc", "P_w", "R_w", "F1_w", "F1_m", "auc_macro_ovr", "infer_s", "ms_per_sample"]}
    row["train_s"] = ms(m, "train_s") if "train_s" in seeds[S[0]][m] else (np.nan, np.nan)
    agg[m] = row
    p = lambda k: f"{100*row[k][0]:.2f} ± {100*row[k][1]:.2f}"
    L.append(f"| {m} | {p('acc')} | {p('P_w')} | {p('R_w')} | {p('F1_w')} | {p('F1_m')} | {p('auc_macro_ovr')} | "
             f"{row['train_s'][0]:.1f} ± {row['train_s'][1]:.1f} | {row['infer_s'][0]:.3f} ± {row['infer_s'][1]:.3f} | "
             f"{row['ms_per_sample'][0]:.4f} ± {row['ms_per_sample'][1]:.4f} |")
L.append("\n## HBN+AE per-class (mean ± std, %)\n| Class | n(test) | Precision | Recall | F1 |\n|---|---|---|---|---|")
for c in CLASSES:
    v = {k: np.array([seeds[s]["HBN+AE"]["per_class"][c][k] for s in S]) for k in ["P", "R", "F1"]}
    n = seeds[S[0]]["HBN+AE"]["per_class"][c]["n"]
    L.append(f"| {c} | {n} | " + " | ".join(f"{100*v[k].mean():.2f} ± {100*v[k].std(ddof=1):.2f}" for k in ["P", "R", "F1"]) + " |")
L.append(f"\n## HBN+AE confusion matrix, seed {S[0]} (rows true, cols predicted; order {CLASSES})\n")
for r in seeds[S[0]]["HBN+AE"]["cm"]: L.append("    " + str(r))
cmsum = np.sum([seeds[s]["HBN+AE"]["cm"] for s in S], 0)
L.append(f"\nSummed over {len(S)} seeds:"); [L.append("    " + str(list(map(int, r)))) for r in cmsum]
L.append("\n## Binary view (attack vs normal) and AE-only gate\n| Seed | HBN+AE det. rate | HBN+AE FPR | AE-only AUC | AE-only det. rate | AE-only FPR | lambda | gamma | bins | k |\n|---|---|---|---|---|---|---|---|---|---|")
for s in S:
    h = seeds[s]["HBN+AE"]; a = h["ae_only_binary"]; b = seeds[s]["bn_selection"]
    L.append(f"| {s} | {100*h['bin_detection_rate']:.2f} | {100*h['bin_FPR']:.2f} | {a['auc']:.4f} | {100*a['det_rate']:.2f} | {100*a['fpr']:.2f} | {h['lam']} | {h['gam']} | {b['n_bins']} | {b['k']} |")
L.append("\n## Sensitivity to k (test, mean over seeds)\n| k | Accuracy | Macro-F1 | Fit (s) | Latency (ms/sample) |\n|---|---|---|---|---|")
for k in ["0", "1", "2", "3", "4"]:
    v = {q: np.array([seeds[s]["k_sensitivity_test"][k][q] for s in S]) for q in ["acc", "F1_m", "fit_s", "ms_per_sample"]}
    L.append(f"| {k} | {100*v['acc'].mean():.2f} ± {100*v['acc'].std(ddof=1):.2f} | {100*v['F1_m'].mean():.2f} ± {100*v['F1_m'].std(ddof=1):.2f} | {v['fit_s'].mean():.2f} | {v['ms_per_sample'].mean():.4f} |")
# paired comparison HBN+AE vs each baseline (accuracy), Wilcoxon not meaningful for n=5 -> report paired differences
L.append("\n## Paired accuracy difference, HBN+AE minus baseline (percentage points, per seed)\n")
for m in MODELS[1:]:
    d = [100 * (seeds[s]["HBN+AE"]["acc"] - seeds[s][m]["acc"]) for s in S]
    L.append(f"- {m}: " + ", ".join(f"{x:+.2f}" for x in d) + f"  (mean {np.mean(d):+.2f})")
open(f"{OUT}/results.md", "w").write("\n".join(L)); json.dump({m: {k: list(v) for k, v in r.items()} for m, r in agg.items()},
                                                             open(f"{OUT}/summary.json", "w"), indent=1, default=float)
# ---------------- figures
M6 = MODELS[:7]; x = np.arange(len(M6)); cols = ["#1f4e79", "#7f7f7f", "#a6a6a6", "#bfbfbf", "#595959", "#8c8c8c", "#c55a11"]
def bar(key, ylabel, fname, scale=100, fmt="{:.2f}"):
    mu = [agg[m][key][0] * scale for m in M6]; sd = [agg[m][key][1] * scale for m in M6]
    fig, ax = plt.subplots(figsize=(8.5, 4.2)); b = ax.bar(x, mu, yerr=sd, capsize=4, color=cols, edgecolor="k")
    for i, v in enumerate(mu): ax.text(i, v + (sd[i] if sd[i] == sd[i] else 0) + max(mu) * 0.01, fmt.format(v), ha="center", fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(M6, rotation=15); ax.set_ylabel(ylabel)
    if scale == 100: ax.set_ylim(max(0, min(mu) - 15), 100)
    ax.grid(axis="y", alpha=.3); fig.tight_layout(); fig.savefig(f"{FIG}/{fname}", dpi=300); plt.close(fig)
bar("acc", "Accuracy (%)", "fig_accuracy.png"); bar("P_w", "Weighted precision (%)", "fig_precision.png")
bar("R_w", "Weighted recall (%)", "fig_recall.png"); bar("F1_w", "Weighted F1-score (%)", "fig_f1.png")
bar("ms_per_sample", "Inference latency (ms/sample)", "fig_latency.png", scale=1, fmt="{:.4f}")
bar("train_s", "Training time (s)", "fig_training_time.png", scale=1, fmt="{:.1f}")
# confusion matrix (seed 0, HBN+AE)
cm = np.array(seeds[S[0]]["HBN+AE"]["cm"]); cmn = cm / cm.sum(1, keepdims=True)
fig, ax = plt.subplots(figsize=(6, 5)); im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
for i in range(6):
    for j in range(6): ax.text(j, i, f"{cm[i,j]}\n({100*cmn[i,j]:.1f}%)", ha="center", va="center", fontsize=7,
                               color="white" if cmn[i, j] > .5 else "black")
ax.set_xticks(range(6)); ax.set_yticks(range(6)); ax.set_xticklabels(CLASSES, rotation=30); ax.set_yticklabels(CLASSES)
ax.set_xlabel("Predicted"); ax.set_ylabel("True"); fig.colorbar(im, fraction=.046); fig.tight_layout()
fig.savefig(f"{FIG}/fig_confusion_matrix_hbnae.png", dpi=300); plt.close(fig)
# ROC / PR (micro-averaged one-vs-rest, seed 0)
z = np.load(f"{OUT}/preds_seed{S[0]}.npz"); y = z["y"]; Y = np.eye(6)[y]
fig1, a1 = plt.subplots(figsize=(6, 5)); fig2, a2 = plt.subplots(figsize=(6, 5))
for m in M6:
    p = z[f"{m}__proba"]; fpr, tpr, _ = roc_curve(Y.ravel(), p.ravel()); a1.plot(fpr, tpr, label=f"{m} (AUC={auc(fpr,tpr):.4f})")
    pr, rc, _ = precision_recall_curve(Y.ravel(), p.ravel()); a2.plot(rc, pr, label=f"{m} (AP={average_precision_score(Y.ravel(), p.ravel()):.4f})")
a1.plot([0, 1], [0, 1], "k--", lw=.8); a1.set_xlabel("False positive rate"); a1.set_ylabel("True positive rate"); a1.legend(fontsize=7); a1.grid(alpha=.3)
a2.set_xlabel("Recall"); a2.set_ylabel("Precision"); a2.legend(fontsize=7); a2.grid(alpha=.3)
fig1.tight_layout(); fig1.savefig(f"{FIG}/fig_roc.png", dpi=300); fig2.tight_layout(); fig2.savefig(f"{FIG}/fig_pr.png", dpi=300)
# AE reconstruction-error distribution
e = z["HBN+AE__ae_err"]; fig, ax = plt.subplots(figsize=(6.5, 4))
for c in range(6): ax.hist(np.log10(e[y == c] + 1e-9), bins=60, alpha=.5, label=CLASSES[c], density=True)
ax.set_xlabel("log10 reconstruction error (AE trained on Benign)"); ax.set_ylabel("Density"); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{FIG}/fig_ae_recon_error.png", dpi=300)
print("\n".join(L))
