"""
HBN-AE re-implementation and baselines on the real UNR-IDD dataset (Python).
Stratified 80/20 split, 5 random seeds; 10% of the training portion is held out
as validation for threshold / hyper-parameter selection and early stopping.
All metrics are computed on the untouched 20% test partition.
"""
import os, sys, json, time, warnings
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, KBinsDiscretizer
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             confusion_matrix, roc_auc_score, average_precision_score,
                             f1_score)
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("DATA_DIR", os.path.join(ROOT, "data", "cic2018"))
OUT = os.environ.get("OUT_DIR", os.path.join(ROOT, "results", "cic2018"))
os.makedirs(OUT, exist_ok=True)
SEEDS = [int(s) for s in os.environ.get("SEEDS", "0,1,2,3,4").split(",")]
CLASSES = ["Benign", "SSH-BruteForce", "DoS-GoldenEye", "DoS-Slowloris", "DoS-Hulk", "DDoS-HOIC"]
NC = len(CLASSES)
NORMAL = 0
tf.config.threading.set_inter_op_parallelism_threads(2)
tf.config.threading.set_intra_op_parallelism_threads(int(os.environ.get("TFT","6")))

# ------------------------------------------------------------------ data
df = pd.read_csv(f"{DATA}/cic2018_subset.csv")
df.columns = [c.strip() for c in df.columns]
y_all = df["Label"].map({c: i for i, c in enumerate(CLASSES)}).values
const_cols = [c for c in df.columns if df[c].nunique() <= 1]
cat_cols = ["Protocol"]
drop = set(const_cols) | {"Label"}
num_cols = [c for c in df.columns if c not in drop and c not in cat_cols]
INFO = dict(n_rows=len(df), n_raw_cols=df.shape[1], n_raw_features=df.shape[1] - 1,
            constant_cols=const_cols, categorical=cat_cols, numeric=num_cols)

def slog(x):
    return np.sign(x) * np.log1p(np.abs(x))

X_num_raw = slog(df[num_cols].astype(float).values)
X_cat = pd.get_dummies(df[cat_cols].astype(str)).values.astype(float)
# discrete codes for the Bayesian network (categoricals kept as single nodes)
cat_codes = np.stack([pd.factorize(df[c])[0] for c in cat_cols], 1)
INFO["n_model_inputs"] = X_num_raw.shape[1] + X_cat.shape[1]
INFO["n_bn_nodes"] = X_num_raw.shape[1] + len(cat_cols)

# ------------------------------------------------------------------ KDB Bayesian network
class KDB:
    """k-dependence Bayesian classifier (Sahami 1996) with MI/CMI structure learning."""
    def __init__(self, k=2, alpha=1.0):
        self.k, self.alpha = k, alpha

    @staticmethod
    def _mi(x, c, nx, nc):
        j = np.zeros((nx, nc)); np.add.at(j, (x, c), 1); j /= j.sum()
        px, pc = j.sum(1, keepdims=True), j.sum(0, keepdims=True)
        m = j > 0
        return float((j[m] * np.log(j[m] / (px @ pc)[m])).sum())

    @staticmethod
    def _cmi(x, z, c, nx, nz, nc):
        j = np.zeros((nx, nz, nc)); np.add.at(j, (x, z, c), 1); j /= j.sum()
        pc = j.sum((0, 1)); pxc = j.sum(1); pzc = j.sum(0)
        m = j > 0
        num = j * pc[None, None, :]
        den = pxc[:, None, :] * pzc[None, :, :]
        return float((j[m] * np.log(num[m] / den[m])).sum())

    def fit(self, X, y):
        n, d = X.shape
        self.card = X.max(0) + 1
        self.nc = int(y.max()) + 1
        mi = np.array([self._mi(X[:, i], y, self.card[i], self.nc) for i in range(d)])
        self.mi = mi
        order = list(np.argsort(-mi))
        cmi = np.zeros((d, d))
        for a in range(d):
            for b in range(a + 1, d):
                v = self._cmi(X[:, a], X[:, b], y, self.card[a], self.card[b], self.nc)
                cmi[a, b] = cmi[b, a] = v
        self.parents = {}
        done = []
        for i in order:
            cand = sorted(done, key=lambda j: -cmi[i, j])[: min(len(done), self.k)]
            self.parents[i] = cand
            done.append(i)
        self.prior = np.log((np.bincount(y, minlength=self.nc) + self.alpha) /
                            (n + self.alpha * self.nc))
        self.cpt = {}
        for i, ps in self.parents.items():
            key = self._key(X, y, ps)                       # parent-config x class
            ki = key * int(self.card[i]) + X[:, i]
            uk, ck = np.unique(key, return_counts=True)
            ui, ci = np.unique(ki, return_counts=True)
            self.cpt[i] = (uk, ck, ui, ci)                  # sparse counts (Laplace at query time)
        return self

    def _key(self, X, c, ps):
        key = np.zeros(len(X), dtype=np.int64)
        for p in ps:
            key = key * int(self.card[p]) + X[:, p]
        return key * self.nc + c

    @staticmethod
    def _lookup(u, cnt, q):
        pos = np.searchsorted(u, q); pos = np.minimum(pos, len(u) - 1)
        return np.where(u[pos] == q, cnt[pos], 0)

    def predict_log_proba(self, X):
        Xc = np.minimum(X, self.card - 1)
        lp = np.tile(self.prior, (len(X), 1))
        for i, ps in self.parents.items():
            uk, ck, ui, ci = self.cpt[i]
            ni = int(self.card[i])
            for c in range(self.nc):
                key = self._key(Xc, np.full(len(X), c), ps)
                nk = self._lookup(uk, ck, key)
                nki = self._lookup(ui, ci, key * ni + Xc[:, i])
                lp[:, c] += np.log((nki + self.alpha) / (nk + self.alpha * ni))
        lp -= lp.max(1, keepdims=True)
        return lp - np.log(np.exp(lp).sum(1, keepdims=True))

    def predict_proba(self, X):
        return np.exp(self.predict_log_proba(X))

# ------------------------------------------------------------------ neural helpers
def dense_ae(d, latent=16, drop=0.1):
    inp = keras.Input((d,))
    h = inp
    for u in (64, 32):
        h = layers.Dense(u, activation="relu")(h); h = layers.BatchNormalization()(h); h = layers.Dropout(drop)(h)
    z = layers.Dense(latent, activation="relu", name="latent")(h)
    h = z
    for u in (32, 64):
        h = layers.Dense(u, activation="relu")(h); h = layers.BatchNormalization()(h)
    out = layers.Dense(d, activation="sigmoid")(h)
    ae = keras.Model(inp, out); enc = keras.Model(inp, z)
    ae.compile(keras.optimizers.Adam(1e-3), "mse")
    return ae, enc

ES = lambda: [keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)]

def fit_ae(Xtr, Xva, seed, epochs=150):
    keras.utils.set_random_seed(seed)
    ae, enc = dense_ae(Xtr.shape[1])
    ae.fit(Xtr, Xtr, validation_data=(Xva, Xva), epochs=epochs, batch_size=256,
           verbose=0, callbacks=ES())
    return ae, enc

def recon_err(ae, X):
    return np.mean((ae.predict(X, batch_size=4096, verbose=0) - X) ** 2, 1)

def clf_head(d, nc):
    m = keras.Sequential([keras.Input((d,)), layers.Dense(128, activation="relu"),
                          layers.Dropout(0.2), layers.Dense(64, activation="relu"),
                          layers.Dense(nc, activation="softmax")])
    m.compile(keras.optimizers.Adam(1e-3), "sparse_categorical_crossentropy", metrics=["accuracy"])
    return m

# ------------------------------------------------------------------ metrics
def metrics(y, yp, proba=None):
    P, R, F, _ = precision_recall_fscore_support(y, yp, average="weighted", zero_division=0)
    Pm, Rm, Fm, _ = precision_recall_fscore_support(y, yp, average="macro", zero_division=0)
    pc = precision_recall_fscore_support(y, yp, labels=range(NC), zero_division=0)
    yb, ypb = (y != NORMAL).astype(int), (yp != NORMAL).astype(int)
    tn, fp, fn, tp = confusion_matrix(yb, ypb, labels=[0, 1]).ravel()
    out = dict(acc=accuracy_score(y, yp), P_w=P, R_w=R, F1_w=F, P_m=Pm, R_m=Rm, F1_m=Fm,
               per_class={CLASSES[i]: dict(P=pc[0][i], R=pc[1][i], F1=pc[2][i], n=int(pc[3][i]))
                          for i in range(NC)},
               cm=confusion_matrix(y, yp, labels=range(NC)).tolist(),
               bin_detection_rate=tp / (tp + fn), bin_FPR=fp / (fp + tn))
    if proba is not None:
        Y = np.eye(NC)[y]
        out["auc_macro_ovr"] = roc_auc_score(Y, proba, average="macro")
        out["ap_macro"] = average_precision_score(Y, proba, average="macro")
    return out

def timed(f, *a):
    t = time.perf_counter(); r = f(*a); return r, time.perf_counter() - t

# ------------------------------------------------------------------ one seed
def run_seed(seed):
    idx = np.arange(len(y_all))
    tr, te = train_test_split(idx, test_size=0.2, stratify=y_all, random_state=seed)
    trn, va = train_test_split(tr, test_size=0.1, stratify=y_all[tr], random_state=seed)
    ytr, yva, yte, yfull = y_all[trn], y_all[va], y_all[te], y_all[tr]
    # continuous representation (scaler fitted on training data only)
    sc = MinMaxScaler().fit(X_num_raw[trn])
    Xc = np.hstack([np.clip(sc.transform(X_num_raw), -0.5, 1.5), X_cat]).astype("float32")
    # discrete representation for the BN (quantile bins fitted on training data only)
    # BN hyper-parameters (number of quantile bins, max parents k) selected on the validation set
    t_sel = time.perf_counter(); sel = []
    for nb in [10, 20, 30, 40, 50]:
        kb_ = KBinsDiscretizer(n_bins=nb, encode="ordinal", strategy="quantile").fit(X_num_raw[trn])
        Xd_ = np.hstack([kb_.transform(X_num_raw).astype(int), cat_codes])
        for k in [1, 2, 3]:
            f = f1_score(yva, KDB(k=k).fit(Xd_[trn], ytr).predict_proba(Xd_[va]).argmax(1), average="macro")
            sel.append((f, nb, k))
    _, NB, K = max(sel)
    t_sel = time.perf_counter() - t_sel
    kb = KBinsDiscretizer(n_bins=NB, encode="ordinal", strategy="quantile").fit(X_num_raw[trn])
    Xd = np.hstack([kb.transform(X_num_raw).astype(int), cat_codes])
    R = {"split": dict(train=len(trn), val=len(va), test=len(te),
                       train_per_class=np.bincount(y_all[tr], minlength=NC).tolist(),
                       test_per_class=np.bincount(yte, minlength=NC).tolist())}
    store = {}

    # ---------------- HBN+AE
    t0 = time.perf_counter()
    kdb = KDB(k=K).fit(Xd[trn], ytr)
    nrm_tr, nrm_va = trn[ytr == NORMAL], va[yva == NORMAL]
    ae, _ = fit_ae(Xc[nrm_tr], Xc[nrm_va], seed)
    e_nva = recon_err(ae, Xc[nrm_va]); mu, sd = e_nva.mean(), e_nva.std()
    # validation-based selection of lambda (tau = mu + lambda*sigma) and gamma (BN verification)
    e_va = recon_err(ae, Xc[va]); p_va = kdb.predict_proba(Xd[va])
    def hbn_decide(e, p, lam, gam):
        tau = mu + lam * sd
        ae_attack = e > tau
        att = np.argmax(p[:, 1:], 1) + 1
        attack = np.where(ae_attack, p[:, NORMAL] < gam,      # AE says attack: BN may veto
                          p[:, NORMAL] < 1 - gam)              # AE says normal: BN may override
        return np.where(attack, att, NORMAL), ae_attack
    best = (-1, None)
    for lam in [0.5, 1, 1.5, 2, 2.5, 3, 4, 5]:
        for gam in [0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 1.01]:
            f = f1_score(yva, hbn_decide(e_va, p_va, lam, gam)[0], average="macro")
            if f > best[0]: best = (f, (lam, gam))
    lam, gam = best[1]
    t_train = time.perf_counter() - t0
    def hbn_infer(Xc_, Xd_):
        e = recon_err(ae, Xc_); p = kdb.predict_proba(Xd_)
        return hbn_decide(e, p, lam, gam), e, p
    ((yp, ae_flag), e_te, p_te), t_inf = timed(hbn_infer, Xc[te], Xd[te])
    # probability used for ROC/PR: BN posterior with the Normal mass re-weighted by the AE gate
    pr = p_te.copy(); g = 1 / (1 + np.exp(-(e_te - (mu + lam * sd)) / (sd + 1e-12)))
    pr[:, NORMAL] *= (1 - g); pr[:, 1:] *= g[:, None]; pr = (pr + 1e-12) / (pr + 1e-12).sum(1, keepdims=True)
    m = metrics(yte, yp, pr); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te),
                                       lam=lam, gam=gam)
    yb = (yte != NORMAL).astype(int)
    m["ae_only_binary"] = dict(auc=roc_auc_score(yb, e_te),
                               det_rate=float(ae_flag[yb == 1].mean()), fpr=float(ae_flag[yb == 0].mean()),
                               acc=float((ae_flag == yb).mean()))
    R["HBN+AE"] = m
    store["HBN+AE"] = dict(proba=pr, yp=yp, ae_err=e_te)
    # ablation: KDB alone
    ypk, tk = timed(lambda: kdb.predict_proba(Xd[te]).argmax(1))
    mk = metrics(yte, ypk, p_te); mk.update(infer_s=tk, ms_per_sample=1e3 * tk / len(te)); R["KDB-BN only"] = mk
    R["bn_selection"] = dict(n_bins=NB, k=K, val_grid=[list(map(float, x)) for x in sel], select_s=t_sel)
    sens = {}
    for k in [0, 1, 2, 3, 4]:
        mm = KDB(k=k); _, tf_ = timed(mm.fit, Xd[trn], ytr); pk, ti = timed(mm.predict_proba, Xd[te])
        sens[k] = dict(acc=accuracy_score(yte, pk.argmax(1)), F1_m=f1_score(yte, pk.argmax(1), average="macro"),
                       fit_s=tf_, ms_per_sample=1e3 * ti / len(te))
    R["k_sensitivity_test"] = sens
    R["kdb_structure"] = {int(i): [int(p) for p in ps] for i, ps in kdb.parents.items()}
    R["kdb_mi"] = kdb.mi.tolist()

    # ---------------- SAE + softmax regression (greedy pre-training then fine-tuning)
    keras.utils.set_random_seed(seed); t0 = time.perf_counter()
    h_tr, h_va, encs = Xc[trn], Xc[va], []
    for u in (64, 32):
        inp = keras.Input((h_tr.shape[1],)); z = layers.Dense(u, activation="relu")(inp)
        o = layers.Dense(h_tr.shape[1], activation="linear")(z)
        a = keras.Model(inp, o); a.compile("adam", "mse")
        a.fit(h_tr, h_tr, validation_data=(h_va, h_va), epochs=60, batch_size=256, verbose=0, callbacks=ES())
        e = keras.Model(inp, z); encs.append(a.layers[1]); h_tr, h_va = e.predict(h_tr, verbose=0), e.predict(h_va, verbose=0)
    inp = keras.Input((Xc.shape[1],)); h = inp
    for L in encs: h = L(h)
    sae = keras.Model(inp, layers.Dense(NC, activation="softmax")(h))
    sae.compile(keras.optimizers.Adam(1e-3), "sparse_categorical_crossentropy")
    sae.fit(Xc[trn], ytr, validation_data=(Xc[va], yva), epochs=150, batch_size=256, verbose=0, callbacks=ES())
    t_train = time.perf_counter() - t0
    p, t_inf = timed(lambda: sae.predict(Xc[te], batch_size=4096, verbose=0))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["SAE+SMR"] = m; store["SAE+SMR"] = dict(proba=p)

    # ---------------- shared unsupervised AE for AE+SVM and AE+Gaussian NB
    t0 = time.perf_counter(); ae2, enc2 = fit_ae(Xc[trn], Xc[va], seed + 100); t_ae2 = time.perf_counter() - t0
    Z = lambda X: enc2.predict(X, batch_size=4096, verbose=0)
    Ztr = Z(Xc[trn])
    zs = MinMaxScaler().fit(Ztr)
    t0 = time.perf_counter(); svm = SVC(C=10, gamma="scale", probability=True, random_state=seed).fit(zs.transform(Ztr), ytr)
    t_train = time.perf_counter() - t0 + t_ae2
    p, t_inf = timed(lambda: svm.predict_proba(zs.transform(Z(Xc[te]))))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["AE+SVM"] = m; store["AE+SVM"] = dict(proba=p)
    t0 = time.perf_counter(); gnb = GaussianNB().fit(Ztr, ytr); t_train = time.perf_counter() - t0 + t_ae2
    p, t_inf = timed(lambda: gnb.predict_proba(Z(Xc[te])))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["AE+Gaussian+NB"] = m; store["AE+Gaussian+NB"] = dict(proba=p)

    # ---------------- MLP
    keras.utils.set_random_seed(seed); t0 = time.perf_counter()
    mlp = clf_head(Xc.shape[1], NC)
    mlp.fit(Xc[trn], ytr, validation_data=(Xc[va], yva), epochs=150, batch_size=256, verbose=0, callbacks=ES())
    t_train = time.perf_counter() - t0
    p, t_inf = timed(lambda: mlp.predict(Xc[te], batch_size=4096, verbose=0))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["MLP"] = m; store["MLP"] = dict(proba=p)

    # ---------------- RNN (GRU over the feature vector treated as a sequence)
    keras.utils.set_random_seed(seed); t0 = time.perf_counter()
    rnn = keras.Sequential([keras.Input((Xc.shape[1], 1)), layers.GRU(64), layers.Dense(64, activation="relu"),
                            layers.Dense(NC, activation="softmax")])
    rnn.compile(keras.optimizers.Adam(1e-3), "sparse_categorical_crossentropy")
    rnn.fit(Xc[trn][..., None], ytr, validation_data=(Xc[va][..., None], yva), epochs=100, batch_size=256,
            verbose=0, callbacks=[keras.callbacks.EarlyStopping(patience=8, restore_best_weights=True)])
    t_train = time.perf_counter() - t0
    p, t_inf = timed(lambda: rnn.predict(Xc[te][..., None], batch_size=4096, verbose=0))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["RNN"] = m; store["RNN"] = dict(proba=p)

    # ---------------- Random Forest
    from sklearn.ensemble import RandomForestClassifier
    t0 = time.perf_counter()
    rf = RandomForestClassifier(n_estimators=100, max_depth=20, n_jobs=6, random_state=seed).fit(Xc[trn], ytr)
    t_train = time.perf_counter() - t0
    p, t_inf = timed(lambda: rf.predict_proba(Xc[te]))
    m = metrics(yte, p.argmax(1), p); m.update(train_s=t_train, infer_s=t_inf, ms_per_sample=1e3 * t_inf / len(te))
    R["RF"] = m; store["RF"] = dict(proba=p)

    np.savez_compressed(f"{OUT}/preds_seed{seed}.npz", y=yte,
                        **{f"{k}__{kk}": vv for k, v in store.items() for kk, vv in v.items()})
    return R

if __name__ == "__main__":
    allR = {"info": INFO, "seeds": {}}
    tag = os.environ.get("TAG", f"s{SEEDS[0]}" if len(SEEDS) == 1 else "all")
    for s in SEEDS:
        t = time.time(); allR["seeds"][s] = run_seed(s)
        print(f"seed {s} done in {time.time()-t:.0f}s :: " +
              ", ".join(f"{k}={v['acc']:.4f}" for k, v in allR["seeds"][s].items() if isinstance(v, dict) and "acc" in v),
              flush=True)
        json.dump(allR, open(f"{OUT}/results_{tag}.json", "w"), indent=1, default=float)
    print("ALL DONE")
