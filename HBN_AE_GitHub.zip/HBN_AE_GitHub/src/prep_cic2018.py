"""CSE-CIC-IDS2018 preprocessing: 4 capture days, cleaning, de-duplication, stratified subset."""
import pandas as pd, numpy as np, json, os
D = os.environ.get("DATA_DIR", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "cic2018"))
FILES = ["wed14", "thu15", "fri16", "wed21"]
MAP = {"Benign": "Benign", "FTP-BruteForce": "FTP-BruteForce", "SSH-Bruteforce": "SSH-BruteForce",
       "DoS attacks-GoldenEye": "DoS-GoldenEye", "DoS attacks-Slowloris": "DoS-Slowloris",
       "DoS attacks-Hulk": "DoS-Hulk", "DoS attacks-SlowHTTPTest": "DoS-SlowHTTPTest",
       "DDOS attack-HOIC": "DDoS-HOIC"}            # DDOS attack-LOIC-UDP (1,730 flows) excluded
CAP = {"Benign": 20000}; CAP_DEFAULT = 10000
log = {}
parts = []
raw_rows = 0; raw_counts = {}
for f in FILES:
    for d in pd.read_csv(f"{D}/{f}.csv", chunksize=200000, dtype=str):
        d.columns = [c.strip() for c in d.columns]
        d = d[d["Label"] != "Label"]
        raw_rows += len(d)
        for k, v in d["Label"].value_counts().items(): raw_counts[k] = raw_counts.get(k, 0) + int(v)
        d = d.drop(columns=["Timestamp", "Dst Port"])
        d = d[d["Label"].isin(MAP)]
        lab = d["Label"].map(MAP).values
        feat = [c for c in d.columns if c != "Label"]
        X = d[feat].apply(pd.to_numeric, errors="coerce").astype("float64")
        X = X.replace([np.inf, -np.inf], np.nan)
        X["Label"] = lab
        parts.append(X)
    print(f, raw_rows, flush=True)
df = pd.concat(parts, ignore_index=True); del parts
log["raw_rows"] = raw_rows; log["raw_label_counts"] = raw_counts
n0 = len(df); df = df.dropna(); log["dropped_nan_inf"] = n0 - len(df)
n0 = len(df); df = df.drop_duplicates(); log["dropped_duplicates"] = n0 - len(df)
# drop feature vectors that appear with conflicting labels
dupX = df.duplicated(subset=feat, keep=False)
log["dropped_conflicting"] = int(dupX.sum()); df = df[~dupX]
log["clean_label_counts"] = df["Label"].value_counts().to_dict()
rng = 2024
sub = pd.concat([g.sample(n=min(len(g), CAP.get(c, CAP_DEFAULT)), random_state=rng)
                 for c, g in df.groupby("Label")], ignore_index=True)
sub = sub.sample(frac=1, random_state=rng).reset_index(drop=True)
log["subset_label_counts"] = sub["Label"].value_counts().to_dict(); log["subset_rows"] = len(sub)
log["n_features_before_constant_removal"] = len(feat)
sub.to_csv(f"{D}/cic2018_subset.csv", index=False)
json.dump(log, open(f"{D}/prep_log.json", "w"), indent=1, default=int)
print(json.dumps(log, indent=1, default=int))
